#include <stdio.h>

int strcmp(const char *s1, const char *s2){
    int i = 0,dif = 0;
    while (s1[i] != '\0' || s2[i] != '\0'){
        dif += (int)s1[i] - (int)s2[i];
        i++;
    }
    return dif;
}

void main(){
    char s1[25], s2[25];
    printf("Enter 2 strings : ");
    scanf("%s %s",s1, s2);
    printf("\n%d",strcmp(s1,s2));
}