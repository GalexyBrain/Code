#include<stdio.h>
int main(){
    int i;
    return 0;
}