#include <stdio.h>
int swap(int a, int b){
    return b, a;
}
int main(){
    int a = 10, b = 20;
    b = swap(a,b);
    printf("a = %d, b = %d\n",a,b);
    return 0;
}